package com.example.RegisterServices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegisterServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
